const responseArray = [
    { quantity: 76 },
    { quantity: 71 },
    { quantity: 10 }
  ]
  
  
      const sum = responseArray.reduce((currentSum, nextObject) => {
  
        // Note that you need to coerce points_earned
        // to a Number or it will simply concatenate the strings
        return currentSum + +nextObject.points_earned;
  
      // 0 is your initial value used by currentSum in
      // the first iteration
      }, 0);
  
  
  console.log(sum);