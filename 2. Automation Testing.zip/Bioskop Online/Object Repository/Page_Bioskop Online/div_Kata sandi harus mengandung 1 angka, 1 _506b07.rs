<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Kata sandi harus mengandung 1 angka, 1 _506b07</name>
   <tag></tag>
   <elementGuidId>6cd38067-cc5e-4e00-ab35-b9bfa0d5918e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='__layout']/div/div[4]/div[2]/div/form/div[4]/label/div[3]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.text-xxs.mb-2.text-red-secondary</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>66d663c1-6edb-47a9-b5c1-0208b44eed0e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>text-xxs mb-2 text-red-secondary</value>
      <webElementGuid>b3bb136a-3d0c-4602-8b99-db904750f1ea</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Kata sandi harus mengandung 1 angka, 1 huruf besar dan 1 huruf kecil.</value>
      <webElementGuid>b476e00c-5745-4730-80f9-8050f17e20a8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;__layout&quot;)/div[@class=&quot;bg-blue-1 flex flex-col min-h-screen text-white font-montserrat&quot;]/div[@class=&quot;vm--container&quot;]/div[@class=&quot;vm--modal modal-classes mx-auto&quot;]/div[@class=&quot;flex flex-col h-full overflow-auto rounded-2xl desktop:w-fit-content bg-blue-1 p-8 mobile:w-full&quot;]/form[1]/div[@class=&quot;mb-4&quot;]/label[1]/div[@class=&quot;text-xxs mb-2 text-red-secondary&quot;]</value>
      <webElementGuid>77e1c7b5-3307-4efe-8e1e-36562f13b34b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='__layout']/div/div[4]/div[2]/div/form/div[4]/label/div[3]</value>
      <webElementGuid>24313a51-931a-468c-a3cd-7e2be3804abf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='*'])[4]/following::div[2]</value>
      <webElementGuid>bd205eba-100d-44cd-8309-297eaf173dfb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Min. 8 karakter berupa kombinasi angka, huruf besar dan huruf kecil'])[1]/preceding::div[1]</value>
      <webElementGuid>5170405a-0a21-46f3-b454-ff3b8e9e1a10</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Lanjutkan'])[1]/preceding::div[2]</value>
      <webElementGuid>640fb8f6-f504-44ff-8f75-1d9e6101b9da</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Kata sandi harus mengandung 1 angka, 1 huruf besar dan 1 huruf kecil.']/parent::*</value>
      <webElementGuid>51f13464-1a0e-456a-b0e7-b0f4d1be78e5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//label/div[3]</value>
      <webElementGuid>f6fff3b4-6563-493d-b04c-320f8f69f432</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Kata sandi harus mengandung 1 angka, 1 huruf besar dan 1 huruf kecil.' or . = 'Kata sandi harus mengandung 1 angka, 1 huruf besar dan 1 huruf kecil.')]</value>
      <webElementGuid>00a758af-4e2f-4c38-b9e9-7794ecaae578</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
